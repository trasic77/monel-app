# Monel – App za predstavnike (MVP)
Minimalni, spreman za deploy (Vite + React + Tailwind).

## Lokalno
```
npm install
npm run dev
```

## Deploy (Vercel)
1) Napravi GitHub repo i pushaj sve.
2) Importaj repo u Vercel i postavi build: `npm run build`, output: `dist`.
3) (Opcionalno) Dodaj Supabase ENV varijable ako kasnije koristiš backend.

Uživaj. 🦉
