import React, { useMemo, useState } from 'react'
import { Calendar, ClipboardList, TriangleAlert, HandCoins, LibraryBig, Home, Link as LinkIcon, FileText, Plus, Vote, ShieldCheck, MessagesSquare } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'

const demoBuilding = { id: 'demo', name: 'SZ Derenčina 22', address: 'Ul. Marijana Derenčina 22, Zagreb', city: 'Zagreb' }
const chip = (text: string) => (<Badge variant='secondary' className='rounded-full px-3 py-1 text-xs'>{text}</Badge>)

export default function App(){
  const [activeTab, setActiveTab] = useState('plan')
  const [tasks, setTasks] = useState<any[]>([
    { id: 't1', title: 'Servis lifta', notes: 'Godišnji servis', due_date: '2025-11-15', status: 'planned', category: 'Lift' },
    { id: 't2', title: 'Čišćenje dimnjaka', notes: 'Redovni pregled', due_date: '2025-11-30', status: 'planned', category: 'Dimnjak' },
  ])
  const [issues, setIssues] = useState<any[]>([])
  const [docs, setDocs] = useState<any[]>([
    { id: 'd1', title: 'Međuvlasnički ugovor (važeći)', url: 'https://example.com/mvu.pdf' },
    { id: 'd2', title: 'Plan održavanja 2025–2030', url: 'https://example.com/plan.pdf' },
  ])
  const [vote, setVote] = useState<any>({
    id: 'v1',
    question: 'Povećati pričuvu na 1,10 €/m² radi sanacije krova?',
    options: [{ id: 'o1', label: 'DA' },{ id: 'o2', label: 'NE' }],
    ballots: [],
  })

  const progress = useMemo(()=>{
    const total = tasks.length || 1
    const done = tasks.filter(t=>t.status==='done').length
    return Math.round((done/total)*100)
  },[tasks])

  return (
    <div className='min-h-screen bg-zinc-50 text-zinc-900'>
      <header className='sticky top-0 z-40 backdrop-blur bg-white/80 border-b'>
        <div className='max-w-6xl mx-auto px-4 py-3 flex items-center justify-between'>
          <div className='flex items-center gap-3'>
            <LibraryBig className='w-6 h-6 text-red-600'/>
            <div>
              <div className='font-bold tracking-tight'>Monel – Bečki standard</div>
              <div className='text-xs text-zinc-500'>App za predstavnike suvlasnika</div>
            </div>
          </div>
          <div className='text-sm text-zinc-500 flex items-center gap-2'>
            <Home className='w-4 h-4'/>{demoBuilding.name}
          </div>
        </div>
      </header>

      <main className='max-w-6xl mx-auto px-4 py-6'>
        <Card className='shadow-sm'>
          <CardHeader className='pb-2'>
            <CardTitle className='text-xl flex items-center gap-2'>
              <ShieldCheck className='w-5 h-5 text-red-600'/> Kontrolna ploča
            </CardTitle>
          </CardHeader>
          <CardContent className='pt-0'>
            <div className='grid grid-cols-1 md:grid-cols-3 gap-4'>
              <StatTile icon={<ClipboardList className='w-4 h-4'/>} label='Zadaci' value={`${tasks.filter(t=>t.status!=='done').length} otvoreno`} />
              <StatTile icon={<TriangleAlert className='w-4 h-4'/>} label='Prijave kvara' value={`${issues.filter(i=>i.status!=='resolved').length} aktivno`} />
              <StatTile icon={<HandCoins className='w-4 h-4'/>} label='Napredak plana' value={<Progress value={progress}/>} />
            </div>
          </CardContent>
        </Card>

        <div className='mt-6'>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className='flex flex-wrap gap-2'>
              <TabsTrigger value='plan' onClick={()=>setActiveTab('plan')}>Plan održavanja</TabsTrigger>
              <TabsTrigger value='issues' onClick={()=>setActiveTab('issues')}>Prijave kvarova</TabsTrigger>
              <TabsTrigger value='votes' onClick={()=>setActiveTab('votes')}>Glasanja</TabsTrigger>
              <TabsTrigger value='finance' onClick={()=>setActiveTab('finance')}>Financije</TabsTrigger>
              <TabsTrigger value='docs' onClick={()=>setActiveTab('docs')}>Dokumenti</TabsTrigger>
              <TabsTrigger value='announce' onClick={()=>setActiveTab('announce')}>Objave</TabsTrigger>
            </TabsList>

            <TabsContent value='plan'><PlanTab tasks={tasks} setTasks={setTasks}/></TabsContent>
            <TabsContent value='issues'><IssuesTab issues={issues} setIssues={setIssues}/></TabsContent>
            <TabsContent value='votes'><VotesTab vote={vote} setVote={setVote}/></TabsContent>
            <TabsContent value='finance'><FinanceTab/></TabsContent>
            <TabsContent value='docs'><DocsTab docs={docs} setDocs={setDocs}/></TabsContent>
            <TabsContent value='announce'><AnnounceTab/></TabsContent>
          </Tabs>
        </div>
      </main>

      <footer className='py-8 text-center text-xs text-zinc-500'>
        © {new Date().getFullYear()} Monel • "Bečki model" – plan, red, transparentnost
      </footer>
    </div>
  )
}

function StatTile({ icon, label, value }: any) {
  return (
    <Card className='border-zinc-200'>
      <CardContent className='py-4'>
        <div className='flex items-center gap-3'>
          <div className='p-2 rounded-xl bg-zinc-100'>{icon}</div>
          <div>
            <div className='text-xs text-zinc-500'>{label}</div>
            <div className='font-semibold'>{value}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function PlanTab({ tasks, setTasks }: any){
  const [title, setTitle] = useState('')
  const [due, setDue] = useState('')
  const [category, setCategory] = useState('')
  const addTask = () => {
    if (!title) return
    const t = { id: crypto.randomUUID(), title, notes: '', due_date: due || undefined, status: 'planned', category }
    setTasks((s:any[]) => [...s, t]); setTitle(''); setDue(''); setCategory('')
  }
  const toggleDone = (id: string) => {
    setTasks((s:any[]) => s.map(it => it.id === id ? { ...it, status: it.status === 'done' ? 'planned' : 'done' } : it));
  }
  return (
    <div className='grid md:grid-cols-3 gap-6'>
      <div className='md:col-span-2'>
        <Card>
          <CardHeader><CardTitle className='flex items-center gap-2'><Calendar className='w-4 h-4'/> Zadatci i rokovi</CardTitle></CardHeader>
          <CardContent>
            <ul className='space-y-3'>
              {tasks.sort((a:any,b:any)=> (a.due_date||'').localeCompare(b.due_date||''))
                .map((t:any)=>(
                  <li key={t.id} className='flex items-start justify-between gap-3 p-3 rounded-xl border'>
                    <div>
                      <div className='font-medium flex items-center gap-2'>{t.title} {t.category && chip(t.category)}</div>
                      <div className='text-xs text-zinc-500'>Rok: {t.due_date ? new Date(t.due_date).toLocaleDateString() : '—'}</div>
                      {t.notes && <div className='text-sm mt-1'>{t.notes}</div>}
                    </div>
                    <div className='flex items-center gap-2'>
                      <Checkbox id={`done-${t.id}`} checked={t.status==='done'} onCheckedChange={()=>toggleDone(t.id)} />
                      <Label htmlFor={`done-${t.id}`} className='text-xs'>Završeno</Label>
                    </div>
                  </li>
                ))}
            </ul>
          </CardContent>
        </Card>
      </div>
      <div>
        <Card>
          <CardHeader><CardTitle className='flex items-center gap-2'><Plus className='w-4 h-4'/> Novi zadatak</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            <div><Label>Naziv</Label><Input value={title} onChange={e=>setTitle(e.target.value)} placeholder='npr. Sanacija pukotine fasade' /></div>
            <div><Label>Kategorija</Label><Input value={category} onChange={e=>setCategory(e.target.value)} placeholder='Krov, Lift, Fasada…' /></div>
            <div><Label>Rok</Label><Input value={due} onChange={e=>setDue(e.target.value)} type='date' /></div>
            <Button onClick={addTask} className='w-full'>Spremi zadatak</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function IssuesTab({ issues, setIssues }: any){
  const [title, setTitle] = useState('')
  const [details, setDetails] = useState('')
  const addIssue = () => {
    if (!title) return
    setIssues((s:any[]) => [{ id: crypto.randomUUID(), title, details, status: 'new' }, ...s])
    setTitle(''); setDetails('')
  }
  const advance = (id: string) => {
    setIssues((s:any[]) => s.map(it => it.id===id ? { ...it, status: it.status === 'new' ? 'assigned' : it.status === 'assigned' ? 'resolved' : 'resolved' } : it));
  }
  return (
    <div className='grid md:grid-cols-3 gap-6'>
      <div className='md:col-span-2'>
        <Card>
          <CardHeader><CardTitle className='flex items-center gap-2'><TriangleAlert className='w-4 h-4'/> Aktivne prijave</CardTitle></CardHeader>
          <CardContent>
            <ul className='space-y-3'>
              {issues.map((i:any)=>(
                <li key={i.id} className='p-3 border rounded-xl flex items-start justify-between gap-3'>
                  <div>
                    <div className='font-medium flex items-center gap-2'>{i.title} {chip(i.status)}</div>
                    {i.details && <div className='text-sm mt-1 text-zinc-700'>{i.details}</div>}
                  </div>
                  <Button variant='secondary' onClick={()=>advance(i.id)}>Sljedeći status</Button>
                </li>
              ))}
              {!issues.length && <div className='text-sm text-zinc-500'>Nema otvorenih prijava.</div>}
            </ul>
          </CardContent>
        </Card>
      </div>
      <div>
        <Card>
          <CardHeader><CardTitle>Nova prijava</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            <div><Label>Naslov</Label><Input value={title} onChange={e=>setTitle(e.target.value)} placeholder='npr. Voda u podrumu' /></div>
            <div><Label>Detalji</Label><Textarea value={details} onChange={e=>setDetails(e.target.value)} placeholder='Kratko objasni problem…' /></div>
            <Button onClick={addIssue} className='w-full'>Spremi prijavu</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function VotesTab({ vote, setVote }: any){
  const [email, setEmail] = useState('')
  const cast = (optionId: string) => {
    if (!email) return alert('Upiši e-mail za evidenciju glasanja.')
    const exists = vote.ballots.find((b:any)=> b.voter_email===email)
    if (exists) return alert('Već je zabilježen glas s tim emailom.')
    setVote((v:any)=> ({...v, ballots: [...v.ballots, { voter_email: email, option_id: optionId }]}))
  }
  const counts = useMemo(()=>{
    const map: Record<string, number> = {}
    vote.options.forEach((o:any)=> map[o.id]=0)
    vote.ballots.forEach((b:any)=> { map[b.option_id] = (map[b.option_id]||0)+1 })
    return map
  },[vote])
  return (
    <div className='grid md:grid-cols-3 gap-6'>
      <div className='md:col-span-2'>
        <Card>
          <CardHeader><CardTitle className='flex items-center gap-2'><Vote className='w-4 h-4'/> E-glasanje</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            <div className='text-lg font-semibold'>{vote.question}</div>
            <div className='grid sm:grid-cols-3 gap-3 mt-2'>
              {vote.options.map((o:any)=> <Button key={o.id} variant='outline' onClick={()=>cast(o.id)}>Glasaj: {o.label}</Button>)}
            </div>
            <div className='border-t pt-3 mt-3'>
              <div className='text-sm font-medium mb-2'>Rezultati</div>
              <div className='space-y-2'>
                {vote.options.map((o:any)=> <div key={o.id} className='flex items-center justify-between'><div>{o.label}</div><Badge>{counts[o.id]||0}</Badge></div>)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <div>
        <Card>
          <CardHeader><CardTitle>Identifikacija glasa</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            <Label>E-mail (za evidenciju)</Label>
            <Input value={email} onChange={e=>setEmail(e.target.value)} placeholder='ime.prezime@example.com' />
            <p className='text-xs text-zinc-500'>*Produkcija: Supabase Auth + ponder po m².</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function DocsTab({ docs, setDocs }: any){
  const [title, setTitle] = useState('')
  const [url, setUrl] = useState('')
  const addDoc = ()=>{
    if (!title || !url) return
    setDocs((s:any[]) => [{ id: crypto.randomUUID(), title, url }, ...s])
    setTitle(''); setUrl('')
  }
  return (
    <div className='grid md:grid-cols-3 gap-6'>
      <div className='md:col-span-2'>
        <Card>
          <CardHeader><CardTitle className='flex items-center gap-2'><FileText className='w-4 h-4'/> Dokumenti</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            {docs.map((d:any)=> (
              <div key={d.id} className='flex items-center justify-between p-3 border rounded-xl'>
                <div className='flex items-center gap-2'><FileText className='w-4 h-4'/><div className='font-medium'>{d.title}</div></div>
                <a href={d.url} target='_blank' className='text-red-600 text-sm inline-flex items-center gap-1'><LinkIcon className='w-4 h-4'/>Otvori</a>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      <div>
        <Card>
          <CardHeader><CardTitle>Novi dokument</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            <div><Label>Naslov</Label><Input value={title} onChange={e=>setTitle(e.target.value)} placeholder='npr. Odluka o pričuvi 2025' /></div>
            <div><Label>URL</Label><Input value={url} onChange={e=>setUrl(e.target.value)} placeholder='https://…' /></div>
            <Button onClick={addDoc} className='w-full'>Dodaj</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function FinanceTab(){
  const [balance, setBalance] = useState(6200)
  const [inAmount, setInAmount] = useState<any>('')
  const [outAmount, setOutAmount] = useState<any>('')
  const addIncome = ()=>{ const v = Number(inAmount||0); if (!v) return; setBalance(b=> b+v); setInAmount('') }
  const addCost   = ()=>{ const v = Number(outAmount||0); if (!v) return; setBalance(b=> Math.max(0, b-v)); setOutAmount('') }
  return (
    <div className='grid md:grid-cols-3 gap-6'>
      <div className='md:col-span-2'>
        <Card>
          <CardHeader><CardTitle className='flex items-center gap-2'><HandCoins className='w-4 h-4'/> Pričuva – brzi pregled</CardTitle></CardHeader>
          <CardContent className='space-y-3'>
            <div className='text-3xl font-bold'>{balance.toLocaleString('hr-HR', { style: 'currency', currency: 'EUR' })}</div>
            <p className='text-sm text-zinc-600'>Simulacija. U produkciji iz tablice funds_transactions.</p>
          </CardContent>
        </Card>
      </div>
      <div className='space-y-4'>
        <Card><CardHeader><CardTitle>Uplata</CardTitle></CardHeader><CardContent className='space-y-2'><Input type='number' value={inAmount} onChange={e=>setInAmount(e.target.value)} placeholder='npr. 1200' /><Button className='w-full' onClick={addIncome}>Dodaj</Button></CardContent></Card>
        <Card><CardHeader><CardTitle>Trošak</CardTitle></CardHeader><CardContent className='space-y-2'><Input type='number' value={outAmount} onChange={e=>setOutAmount(e.target.value)} placeholder='npr. 850' /><Button variant='secondary' className='w-full' onClick={addCost}>Oduzmi</Button></CardContent></Card>
      </div>
    </div>
  )
}

function AnnounceTab(){
  const [text, setText] = useState('')
  const [ann, setAnn] = useState<any[]>([])
  const post = ()=>{ if (!text.trim()) return; setAnn(a=> [{ id: crypto.randomUUID(), text, created_at: new Date().toISOString() }, ...a]); setText('') }
  return (
    <div className='grid md:grid-cols-3 gap-6'>
      <div className='md:col-span-2'>
        <Card><CardHeader><CardTitle className='flex items-center gap-2'><MessagesSquare className='w-4 h-4'/> Obavijesti za suvlasnike</CardTitle></CardHeader>
        <CardContent className='space-y-3'>
          {!ann.length && <div className='text-sm text-zinc-500'>Još nema objava.</div>}
          {ann.map(a=> <div key={a.id} className='p-3 border rounded-xl'><div className='text-sm'>{a.text}</div><div className='text-[10px] text-zinc-500 mt-1'>{new Date(a.created_at).toLocaleString()}</div></div>)}
        </CardContent></Card>
      </div>
      <div>
        <Card><CardHeader><CardTitle>Nova obavijest</CardTitle></CardHeader>
        <CardContent className='space-y-3'>
          <Textarea value={text} onChange={e=>setText(e.target.value)} placeholder='Kratka obavijest…' />
          <Button className='w-full' onClick={post}>Objavi</Button>
        </CardContent></Card>
      </div>
    </div>
  )
}
