import React from 'react'
export function Button({ children, className='', variant='default', ...props }: any){
  const base = 'px-3 py-2 rounded-xl text-sm font-medium transition border'
  const styles = variant==='secondary'
    ? 'bg-zinc-100 hover:bg-zinc-200 border-zinc-200'
    : variant==='outline'
      ? 'bg-white hover:bg-zinc-50 border-zinc-200'
      : 'bg-red-600 hover:bg-red-700 text-white border-red-700'
  return <button className={base+' '+styles+' '+className} {...props}>{children}</button>
}