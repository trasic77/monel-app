import React from 'react'
export function Card({ children, className='' }: any){ return <div className={'bg-white rounded-2xl border '+className}>{children}</div> }
export function CardHeader({ children, className='' }: any){ return <div className={'p-4 '+className}>{children}</div> }
export function CardTitle({ children, className='' }: any){ return <div className={'font-semibold text-lg'}>{children}</div> }
export function CardContent({ children, className='' }: any){ return <div className={'p-4 '+className}>{children}</div> }