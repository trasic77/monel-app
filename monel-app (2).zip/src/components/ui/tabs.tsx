import React from 'react'
export function Tabs({ value, onValueChange, children }: any){ return <div>{children}</div> }
export function TabsList({ children, className='' }: any){ return <div className={'flex gap-2 flex-wrap '+className}>{children}</div> }
export function TabsTrigger({ value, children, onClick }: any){ return <button onClick={onClick} className='px-3 py-1 rounded-full border bg-white hover:bg-zinc-50'>{children}</button> }
export function TabsContent({ children, value }: any){ return <div className='mt-4'>{children}</div> }