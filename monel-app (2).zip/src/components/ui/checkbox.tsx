import React from 'react'
export function Checkbox({ checked, onCheckedChange, id }: any){
  return <input id={id} type='checkbox' className='w-4 h-4 accent-red-600' checked={!!checked} onChange={e=>onCheckedChange?.(e.target.checked)} />
}