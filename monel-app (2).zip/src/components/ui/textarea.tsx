import React from 'react'
export function Textarea({ className='', ...props }: any){
  return <textarea className={'w-full border rounded-xl px-3 py-2 text-sm h-28 focus:outline-none focus:ring-2 focus:ring-red-600 '+className} {...props}/>
}