import React from 'react'
export function Badge({ children, className='', variant='default' }: any){
  const base='inline-flex items-center border rounded-full px-2 py-0.5 text-xs'
  const styles = variant==='secondary' ? 'bg-zinc-100 border-zinc-200' : 'bg-red-50 text-red-700 border-red-200'
  return <span className={base+' '+styles+' '+className}>{children}</span>
}